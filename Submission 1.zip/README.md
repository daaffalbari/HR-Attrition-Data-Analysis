# Menyelesaikan Permsalahan HR Perusahaan Jaya Jaya Maju

## Business Understanding

Jaya Jaya Maju merupakan salah satu perusahaan multinasional yang telah berdiri sejak tahun 2000. Ia memiliki lebih dari 1000 karyawan yang tersebar di seluruh penjuru negeri. Walaupun telah menjadi menjadi perusahaan yang cukup besar, Jaya Jaya Maju masih cukup kesulitan dalam mengelola karyawan. Hal ini berimbas tingginya attrition rate (rasio jumlah karyawan yang keluar dengan total karyawan keseluruhan) hingga lebih dari 10%.

### Permasalahan Bisnis

1. Tingginya attrition rate
2. Keterbatasan monitoring pegawai

### Solution

- Pembuatan dashboard untuk mengidentifikasi faktor-faktor yang memengaruhi attrition rate dan memudahkan HR dalam memonitoring pegawai

## Conclusion

Dari pembuatan dashboard yang telah dilakukan, didapatkan kesimpulan bahwa Attrition rate paling banyak berada pada **Departemen HR** dengan job role **Laboratory Technician & Research Scientist** dan pada **Departemen Sales** dengan job role **Sales Excecutive & Sales Representative**.
Banyak juga karyawan yang keluar dari latar belakang pendidikan teknik dan marketing. Hal yang diperhatikan juga kebijakan lembur/over time yang diberikan kepada karyawan yang berpengaruh pada attrition rate.

## Action items recomendation

1. Mengevaluasi lingkungan pekerjaan pada departemen atau job role yang memiliki tingkat attration yang tinggi guna meningkatkan kepuasan pegawai
2. Mengurangi beban kerja pegawai seperti melakukan penambahan pegawai untuk mengakomodir jumlah pekerjaan yang banyak
3. Memberikan lebih banyak kesempatan pelatihan bagi pegawai agar pegawai dapat berkembang
4. Memberikan gaji dan kenaikan gaji yang sesuai agar pegawai merasa lebih dihargai dan lebih termotivasi
5. Evaluasi dampak jam kerja tambahan (overtime) terhadap tingkat attrition. Pertimbangkan kebijakan yang lebih baik untuk mengelola beban kerja dan mendorong keseimbangan kehidupan kerja yang lebih baik.

## Guides to run project

- Open CMD or PowerShell, to install all requirements, run:

```
pip install -r requirements.txt
```

## Email dan password Metabase

Email: daffaa.albari@gmail.com
Password: dicoding123
